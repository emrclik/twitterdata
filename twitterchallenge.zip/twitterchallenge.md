

```python
# Dependencies
import tweepy
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
import pandas as pd

# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
from config import (consumer_key, 
                    consumer_secret, 
                    access_token, 
                    access_token_secret)

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
target_user = '@CNN'

compound_list = []
positive_list = []
negative_list = []
neutral_list = []

# Loop through 10 pages of tweets (total 200 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user)

    # Loop through all tweets
    for tweet in public_tweets:

        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]

        # Add each value to the appropriate list
        compound_list.append(compound)
        positive_list.append(pos)
        negative_list.append(neg)
        neutral_list.append(neu)
```


```python
cnn_compound = np.mean(compound_list)
cnn_compound
```




    -0.17044000000000001




```python
target_user = '@BBC'

compound_list = []
positive_list = []
negative_list = []
neutral_list = []

# Loop through 10 pages of tweets (total 200 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user)

    # Loop through all tweets
    for tweet in public_tweets:

        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]

        # Add each value to the appropriate list
        compound_list.append(compound)
        positive_list.append(pos)
        negative_list.append(neg)
        neutral_list.append(neu)
```


```python
bbc_compound = np.mean(compound_list)
bbc_compound
```




    0.12481999999999999




```python
target_user = '@CBS'

compound_list = []
positive_list = []
negative_list = []
neutral_list = []

# Loop through 10 pages of tweets (total 200 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user)

    # Loop through all tweets
    for tweet in public_tweets:

        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]

        # Add each value to the appropriate list
        compound_list.append(compound)
        positive_list.append(pos)
        negative_list.append(neg)
        neutral_list.append(neu)

cbs_compound = np.mean(compound_list)
cbs_compound
```




    0.37709500000000007




```python
target_user = '@FoxNews'

compound_list = []
positive_list = []
negative_list = []
neutral_list = []

# Loop through 10 pages of tweets (total 200 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user)

    # Loop through all tweets
    for tweet in public_tweets:

        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]

        # Add each value to the appropriate list
        compound_list.append(compound)
        positive_list.append(pos)
        negative_list.append(neg)
        neutral_list.append(neu)

foxnews_compound = np.mean(compound_list)
foxnews_compound
```




    0.0064600000000000013




```python
target_user = '@nytimes'

compound_list = []
positive_list = []
negative_list = []
neutral_list = []

# Loop through 10 pages of tweets (total 200 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user)

    # Loop through all tweets
    for tweet in public_tweets:

        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]

        # Add each value to the appropriate list
        compound_list.append(compound)
        positive_list.append(pos)
        negative_list.append(neg)
        neutral_list.append(neu)

nytimes_compound = np.mean(compound_list)
nytimes_compound
```




    -0.13574




```python
news_compound_list = [cnn_compound,bbc_compound, cbs_compound, foxnews_compound, nytimes_compound]
news_compound_list
```




    [-0.17044000000000001,
     0.12481999999999999,
     0.37709500000000007,
     0.0064600000000000013,
     -0.13574]




```python
plt.bar(['BBC','CBS','CNN','Fox','NYT'], news_compound_list, color=['orange', 'green', 'red', 'blue', 'cyan'])
plt.title("Overall Media Sentiment based on Twitter")
plt.ylabel('Sentiment Compound')
plt.show()
```


![png](output_9_0.png)



```python
target_user = "@CNN"

# Counter
counter = 1

# Variables for holding sentiments
sentiments_cnn = []

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, page=x+1)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
        # print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        tweets_ago = counter
        
        # Add sentiments for each tweet into an array
        sentiments_cnn.append({"CNN_Compound": compound,
                            "Tweets Ago": counter})
        
        # Add to counter 
        counter = counter + 1
        
# Convert sentiments to DataFrame
cnn_sentiments_pd = pd.DataFrame.from_dict(sentiments_cnn)
cnn_sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CNN_Compound</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.1477</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.8020</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.5659</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.3818</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.0000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.2244</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.0000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.2500</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.2732</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>-0.6597</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>-0.4215</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.1531</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.0000</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>-0.6249</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-0.2960</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>-0.5994</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.0000</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>-0.1531</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.0000</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.5106</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>-0.8481</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>-0.5574</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.3612</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.0000</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>-0.4588</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>-0.0516</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.3182</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.2244</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.0000</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.0000</td>
      <td>71</td>
    </tr>
    <tr>
      <th>71</th>
      <td>-0.4404</td>
      <td>72</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.3612</td>
      <td>73</td>
    </tr>
    <tr>
      <th>73</th>
      <td>0.0000</td>
      <td>74</td>
    </tr>
    <tr>
      <th>74</th>
      <td>-0.4939</td>
      <td>75</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.3612</td>
      <td>76</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.0000</td>
      <td>77</td>
    </tr>
    <tr>
      <th>77</th>
      <td>0.0000</td>
      <td>78</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.0000</td>
      <td>79</td>
    </tr>
    <tr>
      <th>79</th>
      <td>0.1779</td>
      <td>80</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.2716</td>
      <td>81</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.0000</td>
      <td>82</td>
    </tr>
    <tr>
      <th>82</th>
      <td>-0.7003</td>
      <td>83</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.0000</td>
      <td>84</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.0000</td>
      <td>85</td>
    </tr>
    <tr>
      <th>85</th>
      <td>-0.5106</td>
      <td>86</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.0000</td>
      <td>87</td>
    </tr>
    <tr>
      <th>87</th>
      <td>0.0000</td>
      <td>88</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.0000</td>
      <td>89</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.1779</td>
      <td>90</td>
    </tr>
    <tr>
      <th>90</th>
      <td>-0.5994</td>
      <td>91</td>
    </tr>
    <tr>
      <th>91</th>
      <td>-0.1280</td>
      <td>92</td>
    </tr>
    <tr>
      <th>92</th>
      <td>0.0000</td>
      <td>93</td>
    </tr>
    <tr>
      <th>93</th>
      <td>-0.4404</td>
      <td>94</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.2244</td>
      <td>95</td>
    </tr>
    <tr>
      <th>95</th>
      <td>0.0000</td>
      <td>96</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.6908</td>
      <td>97</td>
    </tr>
    <tr>
      <th>97</th>
      <td>0.4588</td>
      <td>98</td>
    </tr>
    <tr>
      <th>98</th>
      <td>-0.1779</td>
      <td>99</td>
    </tr>
    <tr>
      <th>99</th>
      <td>-0.2263</td>
      <td>100</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
target_user = "@BBC"

# Counter
counter = 1

# Variables for holding sentiments
sentiments_bbc = []

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, page=x+1)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
        # print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        tweets_ago = counter
        
        # Add sentiments for each tweet into an array
        sentiments_bbc.append({"BBC_Compound": compound,
                            "Tweets Ago": counter})
        
        # Add to counter 
        counter = counter + 1
        
# Convert sentiments to DataFrame
bbc_sentiments_pd = pd.DataFrame.from_dict(sentiments_bbc)
bbc_sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BBC_Compound</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.2603</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.4574</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.2960</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.0000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.0000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.5267</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.0000</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.0000</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.0000</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.0000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.0000</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.3612</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.0000</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-0.2732</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>-0.2960</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.7717</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.4404</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.0000</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.0000</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.6696</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.0000</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.0000</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>-0.2263</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.0000</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.4215</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.0000</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.0000</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.0000</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>-0.5574</td>
      <td>71</td>
    </tr>
    <tr>
      <th>71</th>
      <td>0.0000</td>
      <td>72</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.3818</td>
      <td>73</td>
    </tr>
    <tr>
      <th>73</th>
      <td>-0.3182</td>
      <td>74</td>
    </tr>
    <tr>
      <th>74</th>
      <td>0.2235</td>
      <td>75</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.0000</td>
      <td>76</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.6705</td>
      <td>77</td>
    </tr>
    <tr>
      <th>77</th>
      <td>-0.4555</td>
      <td>78</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.2449</td>
      <td>79</td>
    </tr>
    <tr>
      <th>79</th>
      <td>-0.2523</td>
      <td>80</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.0000</td>
      <td>81</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.5622</td>
      <td>82</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.0000</td>
      <td>83</td>
    </tr>
    <tr>
      <th>83</th>
      <td>-0.3612</td>
      <td>84</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.0000</td>
      <td>85</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.0000</td>
      <td>86</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.3597</td>
      <td>87</td>
    </tr>
    <tr>
      <th>87</th>
      <td>0.0000</td>
      <td>88</td>
    </tr>
    <tr>
      <th>88</th>
      <td>-0.8481</td>
      <td>89</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.2296</td>
      <td>90</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.0000</td>
      <td>91</td>
    </tr>
    <tr>
      <th>91</th>
      <td>0.4215</td>
      <td>92</td>
    </tr>
    <tr>
      <th>92</th>
      <td>0.0000</td>
      <td>93</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.0000</td>
      <td>94</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.0000</td>
      <td>95</td>
    </tr>
    <tr>
      <th>95</th>
      <td>0.0000</td>
      <td>96</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.0000</td>
      <td>97</td>
    </tr>
    <tr>
      <th>97</th>
      <td>-0.1531</td>
      <td>98</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.6597</td>
      <td>99</td>
    </tr>
    <tr>
      <th>99</th>
      <td>-0.2263</td>
      <td>100</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
target_user = "@CBS"

# Counter
counter = 1

# Variables for holding sentiments
sentiments_cbs = []

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, page=x+1)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
        # print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        tweets_ago = counter
        
        # Add sentiments for each tweet into an array
        sentiments_cbs.append({"CBS_Compound": compound,
                            "Tweets Ago": counter})
        
        # Add to counter 
        counter = counter + 1
        
# Convert sentiments to DataFrame
cbs_sentiments_pd = pd.DataFrame.from_dict(sentiments_cbs)
cbs_sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CBS_Compound</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.6239</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.5859</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.1139</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.3382</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.1867</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.4199</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.0000</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.3595</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.7177</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.1867</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.0000</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.5562</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.7500</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.5574</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.3802</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.3400</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.5859</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.8398</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.4588</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.0000</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.7777</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.2960</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.6369</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.4600</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.8122</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>-0.2057</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.4199</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.0000</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.4877</td>
      <td>71</td>
    </tr>
    <tr>
      <th>71</th>
      <td>0.4939</td>
      <td>72</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.4199</td>
      <td>73</td>
    </tr>
    <tr>
      <th>73</th>
      <td>0.7688</td>
      <td>74</td>
    </tr>
    <tr>
      <th>74</th>
      <td>0.5994</td>
      <td>75</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.0903</td>
      <td>76</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.0000</td>
      <td>77</td>
    </tr>
    <tr>
      <th>77</th>
      <td>0.0000</td>
      <td>78</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.0000</td>
      <td>79</td>
    </tr>
    <tr>
      <th>79</th>
      <td>0.0000</td>
      <td>80</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.2714</td>
      <td>81</td>
    </tr>
    <tr>
      <th>81</th>
      <td>-0.2960</td>
      <td>82</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.5719</td>
      <td>83</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.7650</td>
      <td>84</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.0000</td>
      <td>85</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.0000</td>
      <td>86</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.6360</td>
      <td>87</td>
    </tr>
    <tr>
      <th>87</th>
      <td>0.1280</td>
      <td>88</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.5255</td>
      <td>89</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.8392</td>
      <td>90</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.4389</td>
      <td>91</td>
    </tr>
    <tr>
      <th>91</th>
      <td>0.8268</td>
      <td>92</td>
    </tr>
    <tr>
      <th>92</th>
      <td>0.0000</td>
      <td>93</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.8687</td>
      <td>94</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.7152</td>
      <td>95</td>
    </tr>
    <tr>
      <th>95</th>
      <td>0.0000</td>
      <td>96</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.5106</td>
      <td>97</td>
    </tr>
    <tr>
      <th>97</th>
      <td>0.8877</td>
      <td>98</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.0000</td>
      <td>99</td>
    </tr>
    <tr>
      <th>99</th>
      <td>0.7027</td>
      <td>100</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
target_user = "@FoxNews"

# Counter
counter = 1

# Variables for holding sentiments
sentiments_fox = []

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, page=x+1)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
        # print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        tweets_ago = counter
        
        # Add sentiments for each tweet into an array
        sentiments_fox.append({"FOX_Compound": compound,
                            "Tweets Ago": counter})
        
        # Add to counter 
        counter = counter + 1
        
# Convert sentiments to DataFrame
foxnews_sentiments_pd = pd.DataFrame.from_dict(sentiments_fox)
foxnews_sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>FOX_Compound</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.3400</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.6037</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.4767</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.4767</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.0000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-0.6249</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-0.4767</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.3612</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.0000</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.0000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.0000</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.2500</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>-0.1779</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-0.1027</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.0000</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.0000</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.0000</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.4810</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.4767</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.8176</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.3400</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>-0.1027</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.6705</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>-0.3818</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>-0.6435</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>-0.5574</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>-0.3867</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.0000</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.0000</td>
      <td>71</td>
    </tr>
    <tr>
      <th>71</th>
      <td>0.1531</td>
      <td>72</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.4019</td>
      <td>73</td>
    </tr>
    <tr>
      <th>73</th>
      <td>0.8591</td>
      <td>74</td>
    </tr>
    <tr>
      <th>74</th>
      <td>0.0000</td>
      <td>75</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.0000</td>
      <td>76</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.0000</td>
      <td>77</td>
    </tr>
    <tr>
      <th>77</th>
      <td>0.2263</td>
      <td>78</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.5118</td>
      <td>79</td>
    </tr>
    <tr>
      <th>79</th>
      <td>-0.5574</td>
      <td>80</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.0000</td>
      <td>81</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.7178</td>
      <td>82</td>
    </tr>
    <tr>
      <th>82</th>
      <td>-0.4215</td>
      <td>83</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.0000</td>
      <td>84</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.8567</td>
      <td>85</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.0000</td>
      <td>86</td>
    </tr>
    <tr>
      <th>86</th>
      <td>-0.2500</td>
      <td>87</td>
    </tr>
    <tr>
      <th>87</th>
      <td>0.0000</td>
      <td>88</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.1027</td>
      <td>89</td>
    </tr>
    <tr>
      <th>89</th>
      <td>-0.2960</td>
      <td>90</td>
    </tr>
    <tr>
      <th>90</th>
      <td>-0.2500</td>
      <td>91</td>
    </tr>
    <tr>
      <th>91</th>
      <td>-0.8225</td>
      <td>92</td>
    </tr>
    <tr>
      <th>92</th>
      <td>-0.1280</td>
      <td>93</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.0000</td>
      <td>94</td>
    </tr>
    <tr>
      <th>94</th>
      <td>-0.5267</td>
      <td>95</td>
    </tr>
    <tr>
      <th>95</th>
      <td>-0.2263</td>
      <td>96</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.3182</td>
      <td>97</td>
    </tr>
    <tr>
      <th>97</th>
      <td>-0.4767</td>
      <td>98</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.0000</td>
      <td>99</td>
    </tr>
    <tr>
      <th>99</th>
      <td>-0.2960</td>
      <td>100</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
target_user = "@nytimes"

# Counter
counter = 1

# Variables for holding sentiments
sentiments_nyt = []

# Loop through 5 pages of tweets (total 100 tweets)
for x in range(5):

    # Get all tweets from home feed
    public_tweets = api.user_timeline(target_user, page=x+1)

    # Loop through all tweets 
    for tweet in public_tweets:

        # Print Tweets
        # print("Tweet %s: %s" % (counter, tweet["text"]))
        
        # Run Vader Analysis on each tweet
        results = analyzer.polarity_scores(tweet["text"])
        compound = results["compound"]
        pos = results["pos"]
        neu = results["neu"]
        neg = results["neg"]
        tweets_ago = counter
        
        # Add sentiments for each tweet into an array
        sentiments_nyt.append({"NYT_Compound": compound,
                            "Tweets Ago": counter})
        
        # Add to counter 
        counter = counter + 1
        
# Convert sentiments to DataFrame
nytimes_sentiments_pd = pd.DataFrame.from_dict(sentiments_nyt)
nytimes_sentiments_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>NYT_Compound</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.4767</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.3818</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.6369</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.8346</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.7845</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.0000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.0000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.4404</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.7650</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.0000</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>-0.4588</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>-0.5994</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.4588</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.3400</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-0.7003</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.1280</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.4019</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.0000</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.0000</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.4939</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>-0.3612</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>-0.5574</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>-0.4588</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.5023</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.0000</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.6249</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.0000</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.0000</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>-0.5267</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.0000</td>
      <td>71</td>
    </tr>
    <tr>
      <th>71</th>
      <td>0.4767</td>
      <td>72</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.4939</td>
      <td>73</td>
    </tr>
    <tr>
      <th>73</th>
      <td>-0.5423</td>
      <td>74</td>
    </tr>
    <tr>
      <th>74</th>
      <td>0.8555</td>
      <td>75</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.4215</td>
      <td>76</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.3400</td>
      <td>77</td>
    </tr>
    <tr>
      <th>77</th>
      <td>0.0000</td>
      <td>78</td>
    </tr>
    <tr>
      <th>78</th>
      <td>-0.2023</td>
      <td>79</td>
    </tr>
    <tr>
      <th>79</th>
      <td>-0.5994</td>
      <td>80</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.0000</td>
      <td>81</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.4939</td>
      <td>82</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.0000</td>
      <td>83</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.0258</td>
      <td>84</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.1779</td>
      <td>85</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.1280</td>
      <td>86</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.0000</td>
      <td>87</td>
    </tr>
    <tr>
      <th>87</th>
      <td>-0.5719</td>
      <td>88</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.3716</td>
      <td>89</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.0000</td>
      <td>90</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.0000</td>
      <td>91</td>
    </tr>
    <tr>
      <th>91</th>
      <td>0.6249</td>
      <td>92</td>
    </tr>
    <tr>
      <th>92</th>
      <td>-0.5574</td>
      <td>93</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.0000</td>
      <td>94</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.4404</td>
      <td>95</td>
    </tr>
    <tr>
      <th>95</th>
      <td>-0.2500</td>
      <td>96</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.4019</td>
      <td>97</td>
    </tr>
    <tr>
      <th>97</th>
      <td>0.0000</td>
      <td>98</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.1027</td>
      <td>99</td>
    </tr>
    <tr>
      <th>99</th>
      <td>-0.2960</td>
      <td>100</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
merge_1 = pd.merge(nytimes_sentiments_pd,foxnews_sentiments_pd,on='Tweets Ago')
merge_2 = pd.merge(merge_1,cnn_sentiments_pd,on = 'Tweets Ago')
merge_3 = pd.merge(merge_2,bbc_sentiments_pd,on = 'Tweets Ago')
merged_pd = pd.merge(merge_2,cbs_sentiments_pd,on = 'Tweets Ago')

del merged_pd['Tweets Ago']
merged_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>NYT_Compound</th>
      <th>FOX_Compound</th>
      <th>CNN_Compound</th>
      <th>CBS_Compound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.4767</td>
      <td>0.0000</td>
      <td>0.1477</td>
      <td>0.6239</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.3818</td>
      <td>0.3400</td>
      <td>0.0000</td>
      <td>0.5859</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.6369</td>
      <td>0.6037</td>
      <td>-0.8020</td>
      <td>0.1139</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>-0.5659</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.8346</td>
      <td>-0.4767</td>
      <td>-0.3818</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.7845</td>
      <td>-0.4767</td>
      <td>0.0000</td>
      <td>0.3382</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.2244</td>
      <td>0.1867</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.0000</td>
      <td>-0.6249</td>
      <td>0.0000</td>
      <td>0.4199</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.4404</td>
      <td>-0.4767</td>
      <td>0.2500</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.7650</td>
      <td>0.3612</td>
      <td>0.2732</td>
      <td>0.3595</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>-0.6597</td>
      <td>0.7177</td>
    </tr>
    <tr>
      <th>11</th>
      <td>-0.4588</td>
      <td>0.0000</td>
      <td>-0.4215</td>
      <td>0.1867</td>
    </tr>
    <tr>
      <th>12</th>
      <td>-0.5994</td>
      <td>0.0000</td>
      <td>0.1531</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.4588</td>
      <td>0.2500</td>
      <td>0.0000</td>
      <td>0.5562</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.3400</td>
      <td>-0.1779</td>
      <td>-0.6249</td>
      <td>0.7500</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-0.7003</td>
      <td>-0.1027</td>
      <td>-0.2960</td>
      <td>0.5574</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.1280</td>
      <td>0.0000</td>
      <td>-0.5994</td>
      <td>0.3802</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.4019</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.3400</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>-0.1531</td>
      <td>0.5859</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.0000</td>
      <td>0.4810</td>
      <td>0.0000</td>
      <td>0.8398</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-0.4939</td>
      <td>-0.4767</td>
      <td>-0.5106</td>
      <td>-0.4588</td>
    </tr>
    <tr>
      <th>21</th>
      <td>-0.3612</td>
      <td>0.8176</td>
      <td>-0.8481</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>-0.5574</td>
      <td>0.3400</td>
      <td>-0.5574</td>
      <td>0.7777</td>
    </tr>
    <tr>
      <th>23</th>
      <td>-0.4588</td>
      <td>-0.1027</td>
      <td>0.3612</td>
      <td>0.2960</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.5023</td>
      <td>0.6705</td>
      <td>0.0000</td>
      <td>0.6369</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.0000</td>
      <td>-0.3818</td>
      <td>-0.4588</td>
      <td>0.4600</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.6249</td>
      <td>-0.6435</td>
      <td>-0.0516</td>
      <td>0.8122</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.0000</td>
      <td>-0.5574</td>
      <td>0.3182</td>
      <td>-0.2057</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.0000</td>
      <td>-0.3867</td>
      <td>0.2244</td>
      <td>0.4199</td>
    </tr>
    <tr>
      <th>29</th>
      <td>-0.5267</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.4877</td>
    </tr>
    <tr>
      <th>71</th>
      <td>0.4767</td>
      <td>0.1531</td>
      <td>-0.4404</td>
      <td>0.4939</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.4939</td>
      <td>0.4019</td>
      <td>0.3612</td>
      <td>0.4199</td>
    </tr>
    <tr>
      <th>73</th>
      <td>-0.5423</td>
      <td>0.8591</td>
      <td>0.0000</td>
      <td>0.7688</td>
    </tr>
    <tr>
      <th>74</th>
      <td>0.8555</td>
      <td>0.0000</td>
      <td>-0.4939</td>
      <td>0.5994</td>
    </tr>
    <tr>
      <th>75</th>
      <td>0.4215</td>
      <td>0.0000</td>
      <td>0.3612</td>
      <td>0.0903</td>
    </tr>
    <tr>
      <th>76</th>
      <td>0.3400</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>77</th>
      <td>0.0000</td>
      <td>0.2263</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>78</th>
      <td>-0.2023</td>
      <td>0.5118</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>79</th>
      <td>-0.5994</td>
      <td>-0.5574</td>
      <td>0.1779</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.2716</td>
      <td>0.2714</td>
    </tr>
    <tr>
      <th>81</th>
      <td>0.4939</td>
      <td>0.7178</td>
      <td>0.0000</td>
      <td>-0.2960</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.0000</td>
      <td>-0.4215</td>
      <td>-0.7003</td>
      <td>0.5719</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.0258</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.7650</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.1779</td>
      <td>0.8567</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.1280</td>
      <td>0.0000</td>
      <td>-0.5106</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.0000</td>
      <td>-0.2500</td>
      <td>0.0000</td>
      <td>0.6360</td>
    </tr>
    <tr>
      <th>87</th>
      <td>-0.5719</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.1280</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.3716</td>
      <td>0.1027</td>
      <td>0.0000</td>
      <td>0.5255</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.0000</td>
      <td>-0.2960</td>
      <td>0.1779</td>
      <td>0.8392</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.0000</td>
      <td>-0.2500</td>
      <td>-0.5994</td>
      <td>0.4389</td>
    </tr>
    <tr>
      <th>91</th>
      <td>0.6249</td>
      <td>-0.8225</td>
      <td>-0.1280</td>
      <td>0.8268</td>
    </tr>
    <tr>
      <th>92</th>
      <td>-0.5574</td>
      <td>-0.1280</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>-0.4404</td>
      <td>0.8687</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.4404</td>
      <td>-0.5267</td>
      <td>0.2244</td>
      <td>0.7152</td>
    </tr>
    <tr>
      <th>95</th>
      <td>-0.2500</td>
      <td>-0.2263</td>
      <td>0.0000</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.4019</td>
      <td>0.3182</td>
      <td>0.6908</td>
      <td>0.5106</td>
    </tr>
    <tr>
      <th>97</th>
      <td>0.0000</td>
      <td>-0.4767</td>
      <td>0.4588</td>
      <td>0.8877</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.1027</td>
      <td>0.0000</td>
      <td>-0.1779</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>99</th>
      <td>-0.2960</td>
      <td>-0.2960</td>
      <td>-0.2263</td>
      <td>0.7027</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 4 columns</p>
</div>




```python
merged_pd.plot()
plt.show()
```


![png](output_16_0.png)

